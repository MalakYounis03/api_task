import 'package:get/get.dart';
import 'package:hive_flutter/hive_flutter.dart';

class AuthService extends GetxController {
  static AuthService get instance => Get.find();

  final RxBool isLoggedIn = false.obs;
  final RxString token = ''.obs;

  @override
  void onReady() async {
    await _initHive();
    _checkLoginStatus();
    super.onReady();
  }

  Future<void> _initHive() async {
    await Hive.initFlutter();
    await Hive.openBox('auth');
  }

  void _checkLoginStatus() {
    final box = Hive.box('auth');
    final savedToken = box.get('token');

    if (savedToken != null) {
      token.value = savedToken;
      isLoggedIn.value = true;
    }
  }

  Future<void> login(String newToken) async {
    final box = Hive.box('auth');
    await box.put('token', newToken);

    token.value = newToken;
    isLoggedIn.value = true;
  }

  Future<void> logout() async {
    final box = Hive.box('auth');
    await box.clear();

    token.value = '';
    isLoggedIn.value = false;
  }
}
