import 'package:api_task/app/modules/home/views/widgets/custom_icon.dart';
import 'package:api_task/app/modules/login/views/widgets/custom_text.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../controllers/home_controller.dart';

class HomeView extends GetView<HomeController> {
  const HomeView({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        toolbarHeight: 80,
        backgroundColor: Colors.green[100],
        title: CustomText(text: "Home", color: Colors.white, fontSize: 25),
        centerTitle: true,
        actionsPadding: EdgeInsets.all(10),
        leading: CustomIcon(icon: Icons.add_comment),
        actions: [CustomIcon(icon: Icons.logout)],
      ),
      body: Obx(() {
        if (controller.isLoading.value) {
          return Center(child: CircularProgressIndicator());
        }

        if (controller.posts.isEmpty) {
          return Center(child: Text('No posts available'));
        }

        return ListView.builder(
          padding: const EdgeInsets.all(12),
          itemCount: controller.posts.length,
          itemBuilder: (context, index) {
            final post = controller.posts[index];
            return Container(
              margin: const EdgeInsets.only(bottom: 12),
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(16),
              ),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // صورة المستخدم من الـ API
                  CircleAvatar(
                    radius: 22,
                    backgroundImage: NetworkImage(post.user.imageUrl),
                  ),
                  const SizedBox(width: 10),

                  // تفاصيل البوست من الـ API
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        // الاسم والتاريخ من الـ API
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              post.user.username, // الاسم من الـ API
                              style: TextStyle(
                                fontWeight: FontWeight.bold,
                                fontSize: 15,
                              ),
                            ),
                            Text(
                              '${post.createdAt.day}/${post.createdAt.month}/${post.createdAt.year}', // التاريخ من الـ API
                              style: TextStyle(
                                color: Colors.grey,
                                fontSize: 11,
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 8),
                        Text(
                          post.content, // المحتوى من الـ API
                          style: TextStyle(
                            fontSize: 13,
                            height: 1.5,
                            color: Colors.grey,
                          ),
                          maxLines: 3,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            );
          },
        );
      }),
    );
  }
}
